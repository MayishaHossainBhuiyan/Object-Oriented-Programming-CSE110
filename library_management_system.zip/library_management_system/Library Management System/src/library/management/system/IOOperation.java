package library.management.system;

import java.util.Scanner;

public interface IOOperation {
    void oper(Database database, User user, Scanner scanner);
}
